
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const server = new Server({ name: "weather-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").ListToolsRequestSchema, async () => ({
  tools: [{ name: "get_weather", description: "Get current weather for a city", inputSchema: { type: "object", properties: { city: { type: "string" } }, required: ["city"] } }]
}));
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").CallToolRequestSchema, async (req) => {
  if (req.params.name === "get_weather") {
    // Mock for demo, but can use open-meteo API freely
    const city = req.params.arguments.city;
    return { content: [{ type: "text", text: `Weather in ${city}: 22�C, Sunny. (Mock)` }] };
  }
  throw new Error("Tool not found");
});
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);

