
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const crypto = require("crypto");
const server = new Server({ name: "random-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").ListToolsRequestSchema, async () => ({
  tools: [{ name: "generate_uuid", description: "Generate a random UUID v4", inputSchema: { type: "object", properties: {} } }]
}));
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").CallToolRequestSchema, async (req) => {
  if (req.params.name === "generate_uuid") {
    return { content: [{ type: "text", text: crypto.randomUUID() }] };
  }
  throw new Error("Tool not found");
});
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);

