
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const server = new Server({ name: "hn-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").ListToolsRequestSchema, async () => ({
  tools: [{ name: "get_top_stories", description: "Get HackerNews top stories", inputSchema: { type: "object", properties: { limit: { type: "number", default: 5 } } } }]
}));
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").CallToolRequestSchema, async (req) => {
  if (req.params.name === "get_top_stories") {
    const res = await fetch("https://hacker-news.firebaseio.com/v0/topstories.json");
    const ids = (await res.json()).slice(0, req.params.arguments?.limit || 5);
    const stories = await Promise.all(ids.map(id => fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then(r => r.json())));
    return { content: [{ type: "text", text: JSON.stringify(stories.map(s => ({title: s.title, url: s.url})), null, 2) }] };
  }
  throw new Error("Tool not found");
});
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);

