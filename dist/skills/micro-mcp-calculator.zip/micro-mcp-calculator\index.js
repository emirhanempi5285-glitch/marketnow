
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const server = new Server({ name: "calc-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").ListToolsRequestSchema, async () => ({
  tools: [{ name: "calculate", description: "Evaluate math expression safely", inputSchema: { type: "object", properties: { expr: { type: "string" } }, required: ["expr"] } }]
}));
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").CallToolRequestSchema, async (req) => {
  if (req.params.name === "calculate") {
    try {
      const result = new Function("return " + req.params.arguments.expr)();
      return { content: [{ type: "text", text: String(result) }] };
    } catch(e) {
      return { content: [{ type: "text", text: "Error evaluating expression" }], isError: true };
    }
  }
  throw new Error("Tool not found");
});
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);

