
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const server = new Server({ name: "crypto-mcp", version: "1.0.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").ListToolsRequestSchema, async () => ({
  tools: [{ name: "get_price", description: "Get crypto price", inputSchema: { type: "object", properties: { coin: { type: "string" } }, required: ["coin"] } }]
}));
server.setRequestHandler(require("@modelcontextprotocol/sdk/types.js").CallToolRequestSchema, async (req) => {
  if (req.params.name === "get_price") {
    const coin = req.params.arguments.coin.toLowerCase();
    const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coin}&vs_currencies=usd`);
    const data = await res.json();
    return { content: [{ type: "text", text: data[coin] ? `$${data[coin].usd}` : "Coin not found" }] };
  }
  throw new Error("Tool not found");
});
const transport = new StdioServerTransport();
server.connect(transport).catch(console.error);

